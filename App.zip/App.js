import React, { useEffect, useState } from 'react';
import axios from 'axios';

const options = {
  method: 'GET',
  url: 'https://coinranking1.p.rapidapi.com/coins',
  params: {
    referenceCurrencyUuid: 'yhjMzLPhuIDl',
    timePeriod: '24h',
    'tiers[0]': '1',
    orderBy: 'marketCap',
    orderDirection: 'desc',
    limit: '50',
    offset: '0'
  },
  headers: {
    'X-RapidAPI-Key': '54f158843emshfbf0621c7dec4eap1d98bejsnc1967a1d06fb',
    'X-RapidAPI-Host': 'coinranking1.p.rapidapi.com'
  }
};

const currentDate = new Date(); // Get the current date

// Format the date according to your requirement
const formattedDate = `${currentDate.toLocaleDateString("en-US", { weekday: 'long' })}, ${currentDate.toLocaleDateString("en-US", { day: 'numeric'})} ${currentDate.toLocaleDateString("en-US", { month: 'long' })} ${currentDate.getFullYear()}`;

function App() {
  const [data, setData] = useState([]);
  const [selectedCoin, setSelectedCoin] = useState({});
  const [detailspage, setDetailPage] = useState(true);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  const totalPages = Math.ceil(data.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentData = data.slice(startIndex, endIndex);

  const handlePrevPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const getCoins = async () => {
    try {
      const response = await axios.request(options);
      setData(response?.data?.data?.coins || []);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getCoins();
  }, []);

  const getSelectedCoin = (coin) => {
    const filteredArray = data.filter((c) => c.symbol === coin);
    setSelectedCoin((prevCoin) => filteredArray[0]);
    setDetailPage(false);
  };

  const styleTd = { border: ".5px solid black", padding: "16px" };
  const btn = {
    backgroundColor: "#16a085",
    border:"none",
    color: "white",
    borderRadius: "5px",
    margin: "0px",
    padding: "15px",
    width:"150px"
  };

  return (
    <div>
      <h5 style={{ backgroundColor: "#16a085",margin:"0", padding: "10px",color:"white" }}>
        Market Today ({formattedDate})
      </h5>
      <div  style={{margin:"20px"}}>
        {detailspage ? (
          <div>
            <h3>Price Listing</h3>
            <table width="80%" style={{ borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ backgroundColor: '#e6e9ed' }}>
                  <th style={styleTd}>Symbol</th>
                  <th style={styleTd}>Name</th>
                  <th style={styleTd}>Price(USD)</th>
                  <th style={styleTd}>Change(%)</th>
                </tr>
              </thead>
              <tbody>
                {currentData.map((coin, index) => (
                  <tr key={index}  style={{ cursor: 'pointer' }}>
                    <td style={{ ...styleTd, textDecoration: 'underline', color: 'blue' }}><span onClick={() => getSelectedCoin(coin.symbol)}>{coin.symbol}</span></td>
                    <td style={styleTd}>{coin.name}</td>
                    <td style={{ ...styleTd, textAlign: 'right', fontWeight: 'bold' }}>{coin.price}</td>
                    <td style={{ ...styleTd, textAlign: 'right', color: coin.change >= 0 ? 'green' : 'red' }}>
                      {coin.change >= 0 ? '▲' : '▼'}
                      {coin.change >= 0 ? coin.change : `-${Math.abs(coin.change)}`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <br/>
            <div>
            <button onClick={handleNextPage} disabled={currentPage === totalPages} style={{ float: 'right', padding: '10px', color: 'blue',marginRight:"20%" }}>
            Next {'>'}
          </button>
              <button onClick={handlePrevPage} disabled={currentPage === 1} style={{ float: 'right', padding: '10px', color: 'blue',marginRight:"0" }}>
             {'<'} Prev
              </button>
             
            </div>
          </div>
        ) : (
          <div>
            <h3>Details</h3>
            <table width="70%" style={{ borderCollapse: 'collapse' }}>
              <tbody>
                <tr>
                  <td style={{...styleTd,width:"50%"}}>
                    <div>Symbol</div>
                    <div>{selectedCoin.symbol}</div>
                  </td>
                  <td style={{...styleTd,width:"50%"}}>
                    <div>Name</div>
                    <div>{selectedCoin.name}</div>
                  </td>
                </tr>
                <tr>
                  <td style={styleTd}>
                    <div>Price(USD)</div>
                    <div>{selectedCoin.price}</div>
                  </td>
                  <td style={styleTd}>
                    <div>Change(%)</div>
                    <div style={{color: selectedCoin.change >= 0 ? 'green' : 'red'}}>
                    {selectedCoin.change >= 0 ? '▲' : '▼'}
                    {selectedCoin.change >= 0 ? selectedCoin.change : `-${Math.abs(selectedCoin.change)}`}</div>
                  </td>
                </tr>
                <tr>
                  <td style={styleTd}>
                    <div>Market Cap(USD)</div>
                    <div>{selectedCoin.marketCap}</div>
                  </td>
                  <td style={styleTd}>
                    <div>Rank</div>
                    <div>{selectedCoin.rank}</div>
                  </td>
                </tr>
                <tr>
                  <td style={styleTd}>
                    <div>24 Hours Volume</div>
                    <div>{selectedCoin['24hVolume']}</div>
                  </td>
                  <td style={styleTd}></td>
                </tr>
              </tbody>
            </table>
            <br/>
            <button style={btn} onClick={() => setDetailPage(true)}>
              {'\u003c'} Back to List
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
